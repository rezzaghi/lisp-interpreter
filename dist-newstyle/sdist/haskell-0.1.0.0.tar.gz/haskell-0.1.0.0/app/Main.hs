module Main where

import Data.Char
import Control.Applicative 
import Data.List.Utils (replace)
 
isParenthesis :: Char -> Bool
isParenthesis c =
    if c == '(' || c == ')' then True else False 


tokenize :: String -> [String]
tokenize line = case dropWhile isSpace line of
                    ""  -> []
                    s'  -> w : tokenize s'' 
                        where (w, s'') = span isParenthesis s'

--test "" = [] 
--test x = span isParenthesis
                    
main :: IO ()
main = print $ words $ replace '(' "( " "(bd) (ag)"

